(* $Id: tree.ml 554 2004-12-20 09:53:58Z tsuyoshi $ *)

open Format

module Impl = struct
  type 'elt t =
      TLeaf of 'elt
    | TPair of 'elt t * 'elt t
    | TBag of 'elt t array
end

include Impl

let rec print_sub bracket print_leaf = function
    TLeaf leaf ->
      print_leaf leaf
  | TPair (left, right) ->
      if bracket then begin
        open_box 1;
        print_string "[";
        print_sub true print_leaf left;
        print_string ";";
        print_space ();
        print_sub false print_leaf right;
        print_string "]";
        close_box ()
      end
      else begin
        open_box 0;
        print_sub true print_leaf left;
        print_string ";";
        print_space ();
        print_sub false print_leaf right;
        close_box ()
      end
  | TBag children ->
      let n = Array.length children in
      open_box 1;
      print_string "{";
      if n > 0 then begin
        for i = 0 to n - 2 do
          print_sub true print_leaf children.(i);
          print_string ";";
          print_space ();
        done;
        print_sub true print_leaf children.(n - 1);
      end;
      print_string "}";
      close_box ()

let print print_leaf t = print_sub true print_leaf t

let rec map f = function
    TLeaf leaf -> TLeaf (f leaf)
  | TPair (first, second) -> TPair (map f first, map f second)
  | TBag children -> TBag (Array.map (map f) children)

let graph_tree vertices_tree =
  let make_adj_list v path =
    let rec iter1 path1 = function
        TLeaf w ->
          assert (path1 = []);
          TLeaf ((v, w))
      | TPair (first, second) ->
          let (path_first, path_second) =
            match path1 with
                [] -> ([], [])
              | 0 :: path2 -> (path2, [])
              | 1 :: path2 -> ([], path2)
              | _ -> assert false
          in
          TPair (iter1 path_first first, iter1 path_second second)
      | (TBag children) as tree ->
          match path1 with
              [] ->
                TBag (Array.map (iter1 []) children)
            | anc_idx :: path2 ->
                let first = children.(anc_idx) in
                let second =
                  Array.init (Array.length children - 1)
                    begin fun i ->
                      if i < anc_idx then
                        children.(i)
                      else
                        children.(i + 1)
                    end
                in
                TPair (iter1 path2 first,
                            TBag (Array.map (iter1 []) second))
    in
    iter1 path vertices_tree
  in
  let rec map_to_adj_list path = function
      TLeaf v ->
        make_adj_list v (List.rev path)
    | TPair (first, second) ->
        TPair (map_to_adj_list (0 :: path) first,
                    map_to_adj_list (1 :: path) second)
    | (TBag children) as tree ->
        let new_children =
          Array.mapi
            (fun i child -> map_to_adj_list (i :: path) child) children
        in
        TBag new_children
  in
  map_to_adj_list [] vertices_tree

module type S = sig
  type elt
  type 'elt impl = 'elt Impl.t =
      TLeaf of 'elt
    | TPair of 'elt impl * 'elt impl
    | TBag of 'elt impl array
  type t = elt impl
  val compare: t -> t -> int
  val normalize: t -> unit
  val print: (elt -> unit) -> t -> unit
  val map: (elt -> 'a) -> t -> 'a Impl.t
end

module Make(Elt: Set.OrderedType): S with type elt = Elt.t = struct

  type elt = Elt.t

  type 'elt impl = 'elt Impl.t =
      TLeaf of 'elt
    | TPair of 'elt impl * 'elt impl
    | TBag of 'elt impl array

  type t = elt impl

  let rec compare t1 t2 =
    match (t1, t2) with
        (TLeaf leaf1, TLeaf leaf2) -> Elt.compare leaf1 leaf2
      | (TPair (first1, second1), TPair (first2, second2)) ->
          let res = compare first1 first2 in
          if res <> 0 then
            res
          else
            let res = compare second1 second2 in
            if res <> 0 then
              res
            else
              0
      | (TBag children1, TBag children2) ->
          let len1 = Array.length children1 in
          let len2 = Array.length children2 in
          if len1 <> len2 then
            Pervasives.compare len1 len2
          else
            let rec iter1 i =
              if i >= len1 then
                0
              else
                let res = compare children1.(i) children2.(i) in
                if res <> 0 then
                  res
                else
                  iter1 (i + 1)
            in
            iter1 0
      | (_, _) ->
          failwith "compare: Type mismatch"

  let rec normalize = function
      TLeaf _ -> ()
    | TPair (first, second) ->
        normalize first;
        normalize second
    | TBag children ->
        Array.iter normalize children;
        Array.sort compare children

  let print = print
  let map = map

end
