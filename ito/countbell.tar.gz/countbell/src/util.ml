(* $Id: util.ml 559 2004-12-21 05:24:21Z tsuyoshi $ *)

open Num

let equal_num_array a b =
  let len = Array.length a in
  if Array.length b <> len then
    false
  else
    let rec iter1 i =
      if i >= len then
        true
      else if a.(i) <>/ b.(i) then
        false
      else
        iter1 (i + 1)
    in
    iter1 0

let next_permutation_sub perm off len =
  if len = 0 then
    false
  else begin
    let rec iter1 i =
      if i = off || perm.(i - 1) < perm.(i) then
        i
      else
        iter1 (i - 1)
    in
    let tail = iter1 (off + len - 1) in
    if tail > off then begin
      let pivot = perm.(tail - 1) in
      let rec iter2 i =
        if pivot < perm.(i) then
          i
        else
          iter2 (i - 1)
      in
      let j = iter2 (off + len - 1) in
      perm.(tail - 1) <- perm.(j);
      perm.(j) <- pivot
    end;
    let rec iter3 l r =
      if l >= r then
        ()
      else begin
        let tmp = perm.(l) in
        perm.(l) <- perm.(r);
        perm.(r) <- tmp;
        iter3 (l + 1) (r - 1)
      end
    in
    iter3 tail (off + len - 1);
    tail <> off
  end

let next_permutation perm =
  next_permutation_sub perm 0 (Array.length perm)

let unique equal =
  let rec iter1 res_hd res_tl = function
      [] -> List.rev (res_hd :: res_tl)
    | hd :: tl ->
        if equal res_hd hd then
          iter1 res_hd res_tl tl
        else
          iter1 hd (res_hd :: res_tl) tl
  in
  function
      [] -> []
    | hd :: tl ->
        iter1 hd [] tl
