(* $Id: ineqK1mm.ml 556 2004-12-21 02:15:02Z tsuyoshi $ *)

open Printf
open Util

module type NumberType = sig
  type t
  val of_int: int -> t
  val sign: t -> int
  val compare: t -> t -> int
  val add: t -> t -> t
  val minus: t -> t
  val equal: t -> t -> bool
  val to_string: t -> string
end

module type CommonType = sig
  type vertex =
      X
    | A of int
    | B of int
end

module Common = struct
  type vertex =
      X
    | A of int
    | B of int
end
include Common

let for_each_edge m1 m2 f =
  for i = 0 to m1 - 1 do
    f X (A(i))
  done;
  for j = 0 to m2 - 1 do
    f X (B(j))
  done;
  for i = 0 to m1 - 1 do
    for j = 0 to m2 - 1 do
      f (A(i)) (B(j))
    done
  done

module type S = sig
  type number

  type vertex =
      Common.vertex =
      X
    | A of int
    | B of int
  type t

  val make : int -> int -> t
  val init : int -> int -> number -> (vertex -> vertex -> number) -> t
  val copy : t -> t
  val get_m1 : t -> int
  val get_m2 : t -> int
  val get_coeff : t -> vertex -> vertex -> number
  val set_coeff : t -> vertex -> vertex -> number -> unit
  val get_const_coeff : t -> number
  val set_const_coeff : t -> number -> unit
  val equal : t -> t -> bool
  val print : t -> unit
  val permute : int array -> int array -> t -> t
  val exchange_partites : t -> t
  val minimize : t -> t
  val switch : (vertex -> 'a) -> t -> t
  val equal_perm: t -> t -> bool
  val equal_perm_within_partites: t -> t -> bool
  val equal_perm_sw: t -> t -> bool
  val collapse: int -> int -> (vertex -> vertex) -> t -> t
end

module Make(Number: NumberType) = struct
  type number = Number.t

  module NumTree = Tree.Make(Number)

  let zero = Number.of_int 0

  let equal_array arr arr' =
    let len = Array.length arr in
    assert (Array.length arr' = len);
    let rec iter1 i =
      if i >= len then
        true
      else if not (Number.equal arr.(i) arr'.(i)) then
        false
      else
        iter1 (i + 1)
    in
    iter1 0

  type vertex =
      Common.vertex =
      X
    | A of int
    | B of int

  type t = {
    m1: int;
    m2: int;
    a: number array;
    mutable sorted_coeff: number array option;
  }

  let get_edge_idx t v w =
    match (v, w) with
        (X, A(i)) | (A(i), X) ->
          assert (i >= 0 && i < t.m1);
          1 + i
      | (X, B(j)) | (B(j), X) ->
          assert (j >= 0 && j < t.m2);
          1 + t.m1 + j
      | (A(i), B(j)) | (B(j), A(i)) ->
          assert (i >= 0 && i < t.m1 && j >= 0 && j < t.m2);
          1 + t.m1 + t.m2 + i * t.m2 + j
      | (_, _) ->
          raise Not_found

  let make m1 m2 =
    {
      m1 = m1;
      m2 = m2;
      a = Array.make (1 + m1 + m2 + m1 * m2) zero;
      sorted_coeff = None;
    }

  let get_sorted_coeff t =
    match t.sorted_coeff with
        Some(sorted_coeff) -> sorted_coeff
      | None ->
          let sorted_coeff = Array.sub t.a 1 (t.m1 + t.m2 + t.m1 * t.m2) in
          Array.sort Number.compare sorted_coeff;
          t.sorted_coeff <- Some(sorted_coeff);
          sorted_coeff

  let copy t =
    {
      t with a = Array.copy t.a;
    }

  let get_m1 t =
    t.m1

  let get_m2 t =
    t.m2

  let get_coeff t v w =
    t.a.(get_edge_idx t v w)

  let set_coeff t v w coeff =
    t.a.(get_edge_idx t v w) <- coeff;
    t.sorted_coeff <- None

  let get_const_coeff t =
    t.a.(0)

  let set_const_coeff t coeff =
    t.a.(0) <- coeff

  let init m1 m2 const_coeff f =
    let t = make m1 m2 in
    set_const_coeff t const_coeff;
    for_each_edge m1 m2
      (fun v w -> set_coeff t v w (f v w));
    t

  let equal t1 t2 =
    assert (t1.m1 = t2.m1 && t1.m2 = t2.m2);
    equal_array t1.a t2.a

  let print t =
    print_char ' ';
    Array.iter
      begin fun coeff ->
        printf " %s" (Number.to_string coeff)
      end
      t.a;
    print_newline ()

  let permute_equal vs1 vs2 t t' =
    let m1 = t.m1 in
    let m2 = t.m2 in
    assert (t.m1 = t'.m1 && t.m2 = t'.m2);
    assert (Array.length vs1 = t.m1 && Array.length vs2 = t.m2);
    try
      if not (Number.equal (get_const_coeff t) (get_const_coeff t')) then
        raise Exit;
      for i = 0 to m1 - 1 do
        if not (Number.equal (get_coeff t X (A(vs1.(i)))) (get_coeff t' X (A(i)))) then
          raise Exit
      done;
      for j = 0 to m2 - 1 do
        if not (Number.equal (get_coeff t X (B(vs2.(j)))) (get_coeff t' X (B(j)))) then
          raise Exit
      done;
      for i = 0 to m1 - 1 do
        for j = 0 to m2 - 1 do
          if not (Number.equal (get_coeff t (A(vs1.(i))) (B(vs2.(j)))) (get_coeff t' (A(i)) (B(j)))) then
            raise Exit
        done
      done;
      true
    with Exit -> false

  let permute vs1 vs2 t =
    let m1' = Array.length vs1 in
    let m2' = Array.length vs2 in
    let t' = make m1' m2' in
    set_const_coeff t' (get_const_coeff t);
    for i = 0 to m1' - 1 do
      set_coeff t' X (A(i)) (get_coeff t X (A(vs1.(i))))
    done;
    for j = 0 to m2' - 1 do
      set_coeff t' X (B(j)) (get_coeff t X (B(vs2.(j))))
    done;
    for i = 0 to m1' - 1 do
      for j = 0 to m2' - 1 do
        set_coeff t' (A(i)) (B(j)) (get_coeff t (A(vs1.(i))) (B(vs2.(j))))
      done
    done;
    t'

  let exchange_partites t =
    let t' = make t.m2 t.m1 in
    set_const_coeff t' (get_const_coeff t);
    for i = 0 to t'.m1 - 1 do
      set_coeff t' X (A(i)) (get_coeff t X (B(i)))
    done;
    for j = 0 to t'.m2 - 1 do
      set_coeff t' X (B(j)) (get_coeff t X (A(j)))
    done;
    for i = 0 to t'.m1 - 1 do
      for j = 0 to t'.m2 - 1 do
        set_coeff t' (A(i)) (B(j)) (get_coeff t (A(j)) (B(i)))
      done
    done;
    t'

  let minimize t =
    let m1 = t.m1 in
    let m2 = t.m2 in
    let vertex_used1 = Array.make m1 false in
    let vertex_used2 = Array.make m2 false in
    for i = 0 to m1 - 1 do
      if Number.sign (get_coeff t X (A(i))) <> 0 then
        vertex_used1.(i) <- true
    done;
    for j = 0 to m2 - 1 do
      if Number.sign (get_coeff t X (B(j))) <> 0 then
        vertex_used2.(j) <- true
    done;
    for i = 0 to m1 - 1 do
      for j = 0 to m2 - 1 do
        if Number.sign (get_coeff t (A(i)) (B(j))) <> 0 then begin
          vertex_used1.(i) <- true;
          vertex_used2.(j) <- true
        end
      done
    done;
    let m1' = ref 0 in
    let m2' = ref 0 in
    let vs1 = Array.make m1 (-1) in
    let vs2 = Array.make m2 (-1) in
    for i = 0 to m1 - 1 do
      if vertex_used1.(i) then begin
        vs1.(!m1') <- i;
        incr m1'
      end
    done;
    for j = 0 to m2 - 1 do
      if vertex_used2.(j) then begin
        vs2.(!m2') <- j;
        incr m2'
      end
    done;
    let m1' = !m1' in
    let m2' = !m2' in
    let vs1 = Array.sub vs1 0 m1' in
    let vs2 = Array.sub vs2 0 m2' in
    permute vs1 vs2 t

  let switch cut t =
    let m1 = t.m1 in
    let m2 = t.m2 in
    let t' = copy t in
    for_each_edge m1 m2
      begin fun v w ->
        if cut v <> cut w then begin
          let edge_idx = get_edge_idx t v w in
          let c = t'.a.(edge_idx) in
          set_const_coeff t'
            (Number.add (get_const_coeff t') c);
          t'.a.(edge_idx) <- Number.minus c
        end
      end;
    t'.sorted_coeff <- None;
    t'

  let test_permutations t t' =
    if t.m1 <> t'.m1 || t.m2 <> t'.m2 then
      false
    else
      let m1 = t.m1 in
      let m2 = t.m2 in
      let vs1 = Array.init m1 (fun i -> i) in
      let vs2 = Array.init m2 (fun j -> j) in
      let rec iter1 () =
        if permute_equal vs1 vs2 t t' then
          true
        else if next_permutation vs2 || next_permutation vs1 then
          iter1 ()
        else
          false
      in
      iter1 ()

  let equal_perm t t' =
    assert (t.m1 <= t.m2);
    assert (t'.m1 <= t'.m2);
    if t.m1 <> t'.m1 || t.m2 <> t'.m2 then
      false
    else if not (Number.equal (get_const_coeff t) (get_const_coeff t')) then
      false
    else if not (equal_array (get_sorted_coeff t) (get_sorted_coeff t')) then
      false
    else if test_permutations t t' then
      true
    else if t.m1 <> t.m2 then
      false
    else
      test_permutations (exchange_partites t) t'

  let equal_perm_within_partites t t' =
    if t.m1 <> t'.m1 || t.m2 <> t'.m2 then
      false
    else if not (Number.equal (get_const_coeff t) (get_const_coeff t')) then
      false
    else if not (equal_array (get_sorted_coeff t) (get_sorted_coeff t')) then
      false
    else
      test_permutations t t'

  let equal_perm_sw t t' =
    assert (t.m1 <= t.m2);
    assert (t'.m1 <= t'.m2);
    if t.m1 <> t'.m1 || t.m2 <> t'.m2 then
      false
    else
      let m1 = t.m1 in
      let m2 = t.m2 in
      let cuts_cnt = 1 lsl (m1 + m2) in
      let rec iter1 cut =
        if cut = cuts_cnt then
          false
        else
          let get_cut = function
              X -> false
            | A(i) -> (cut lsr i) land 1 <> 0
            | B(j) -> (cut lsr (m1 + j)) land 1 <> 0
          in
          if equal_perm (switch get_cut t) t' then
            true
          else
            iter1 (cut + 1)
      in
      iter1 0

  let collapse m1' m2' vmap t =
    let m1 = t.m1 in
    let m2 = t.m2 in
    let t' = make m1' m2' in
    set_const_coeff t' (get_const_coeff t);
    for_each_edge m1 m2
      begin fun v w ->
        let v' = vmap v in
        let w' = vmap w in
        if v' <> w' then
          set_coeff t' v' w'
            (Number.add (get_coeff t' v' w') (get_coeff t v w))
      end;
    t'
end
