(* $Id: triliftCompare.ml 559 2004-12-21 05:24:21Z tsuyoshi $ *)

open Util

module type NumberType = sig
  type t
  val of_int: int -> t
  val sign: t -> int
  val compare: t -> t -> int
  val add: t -> t -> t
  val sub: t -> t -> t
  val mult: t -> t -> t
  val div: t -> t -> t
  val minus: t -> t
  val equal: t -> t -> bool
  val abs: t -> t
  val to_string: t -> string
end

module type S = sig
  type number
  module IneqKn: IneqKn.S
  module IneqK1mm: IneqK1mm.S

  type perm_sw_invariant
  type perm_invariant

  val count_internal_edges: int -> int -> int -> IneqKn.t -> int * int
  val enumerate_internal_edges:
    int -> int -> int -> IneqKn.t -> (int * int) array * (int * int) array
  type normal_facet = {
    facet_n0: int;
    facet_n1: int;
    facet_n2: int;
    facet_ineq: IneqKn.t;
    facet_perm_sw_invariant: perm_sw_invariant;
    facet_perm_invariant: perm_invariant;
  }
  val switch_normal_facet: int -> normal_facet -> normal_facet
  val compare_facet_perm: normal_facet -> normal_facet -> bool
  val compare_facet_perm_sw: normal_facet -> normal_facet -> bool
  val normalize_facet: int -> int -> int -> IneqKn.t -> normal_facet
  val trilift_ineq:
    int -> int -> int -> IneqKn.t -> IneqK1mm.t
  val cut_to_cor_ineq:
    IneqK1mm.t -> number * number array
end

module Make(Number: NumberType) = struct
  type number = Number.t
  module IneqKn = IneqKn.Make(Number)
  module IneqK1mm = IneqK1mm.Make(Number)

  let zero = Number.of_int 0
  let two = Number.of_int 2

  let perm_invariant_spec n0 n1 n2 =
    let v0 = if n0 = 1 then 0 else (-1) in
    let vs1 = Array.init n1 (fun i -> i + n0) in
    let vs2 = Array.init n2 (fun j -> j + n0 + n1) in
    let vertices_tree =
      Tree.TPair (Tree.TLeaf v0,
                  Tree.TBag [|Tree.TBag (Array.map (fun v -> Tree.TLeaf v) vs1);
                              Tree.TBag (Array.map (fun v -> Tree.TLeaf v) vs2)|])
    in
    Tree.graph_tree vertices_tree

  module NumTree = Tree.Make(Number)

  let count_internal_edges n0 n1 n2 ineq =
    let n = n0 + n1 + n2 in
    assert (IneqKn.get_n ineq = n);
    let internal_edges1 = ref 0 in
    let internal_edges2 = ref 0 in
    for i = 0 to n1 - 2 do
      for j = i + 1 to n1 - 1 do
        let vi = i + n0 in
        let vj = j + n0 in
        if Number.sign (IneqKn.get_coeff ineq vi vj) <> 0 then
          incr internal_edges1
      done
    done;
    for i = 0 to n2 - 2 do
      for j = i + 1 to n2 - 1 do
        let vi = i + n0 + n1 in
        let vj = j + n0 + n1 in
        if Number.sign (IneqKn.get_coeff ineq vi vj) <> 0 then
          incr internal_edges2
      done
    done;
    (!internal_edges1, !internal_edges2)

  let enumerate_internal_edges n0 n1 n2 ineq =
    let n = n0 + n1 + n2 in
    assert (IneqKn.get_n ineq = n);
    let internal_edges1 = ref [] in
    let internal_edges2 = ref [] in
    for i = 0 to n1 - 2 do
      for j = i + 1 to n1 - 1 do
        let vi = i + n0 in
        let vj = j + n0 in
        if Number.sign (IneqKn.get_coeff ineq vi vj) <> 0 then
          internal_edges1 := (vi, vj) :: !internal_edges1
      done
    done;
    for i = 0 to n2 - 2 do
      for j = i + 1 to n2 - 1 do
        let vi = i + n0 + n1 in
        let vj = j + n0 + n1 in
        if Number.sign (IneqKn.get_coeff ineq vi vj) <> 0 then
          internal_edges2 := (vi, vj) :: !internal_edges2
      done
    done;
    (Array.of_list (List.rev !internal_edges1),
     Array.of_list (List.rev !internal_edges2))

  (** Return permutation invariant (if also_sw is false) or
      permutation-switching invariant (if also_sw is true). *)
  let perm_invariant also_sw n0 n1 n2 ineq =
    let n = IneqKn.get_n ineq in
    assert (n0 + n1 + n2 = n);
    let spec = perm_invariant_spec n0 n1 n2 in
    let inv =
      if also_sw then
        Tree.map (fun (vi, vj) -> if vi < 0 || vj < 0 || vi = vj then zero else Number.abs (IneqKn.get_coeff ineq vi vj)) spec
      else
        Tree.TPair (Tree.TLeaf (IneqKn.get_const_coeff ineq),
                    Tree.map (fun (vi, vj) -> if vi < 0 || vj < 0 || vi = vj then zero else IneqKn.get_coeff ineq vi vj) spec)
    in
    NumTree.normalize inv;
    inv

  type perm_sw_invariant = NumTree.t
  type perm_invariant = NumTree.t

  type normal_facet = {
    facet_n0: int;
    facet_n1: int;
    facet_n2: int;
    facet_ineq: IneqKn.t;
    facet_perm_sw_invariant: perm_sw_invariant;
    facet_perm_invariant: perm_invariant;
  }

  let switch_normal_facet cut nf =
    let n0 = nf.facet_n0 in
    let n1 = nf.facet_n1 in
    let n2 = nf.facet_n2 in
    let ineq = IneqKn.switch cut nf.facet_ineq in
    {
      nf with
        facet_ineq = ineq;
        facet_perm_invariant = perm_invariant false n0 n1 n2 ineq
    }

  let test_permutations n0 n1 n2 ineq_a ineq_b =
    let n = n0 + n1 + n2 in
    let perm = Array.init n (fun i -> i) in
    let rec iter1 () =
      if IneqKn.permute_equal perm ineq_a ineq_b then
        true
      else if (next_permutation_sub perm (n0 + n1) n2 ||
                 next_permutation_sub perm n0 n1) then
        iter1 ()
      else
        false
    in
    iter1 ()

  let compare_facet_perm nf nf' =
    assert (nf.facet_n1 <= nf.facet_n2);
    assert (nf'.facet_n1 <= nf'.facet_n2);
    if (nf.facet_n0 <> nf'.facet_n0 ||
          nf.facet_n1 <> nf'.facet_n1 ||
          nf.facet_n2 <> nf'.facet_n2) then
      false
    else
      let perm_invar = nf.facet_perm_invariant in
      let perm_invar' = nf'.facet_perm_invariant in
      if NumTree.compare perm_invar perm_invar' <> 0 then
        false
      else 
        let n0 = nf.facet_n0 in
        let n1 = nf.facet_n1 in
        let n2 = nf.facet_n2 in
        if test_permutations n0 n1 n2 nf.facet_ineq nf'.facet_ineq then
          true
        else if n1 <> n2 then
          false
        else
          let vs0 = Array.init n0 (fun i -> i) in
          let vs1 = Array.init n2 (fun i -> i + n0 + n1) in
          let vs2 = Array.init n1 (fun i -> i + n0) in
          let ineq =
            IneqKn.permute (Array.concat [vs0; vs1; vs2]) nf.facet_ineq
          in
          test_permutations n0 n2 n1 ineq nf'.facet_ineq

  let compare_facet_perm_sw nf nf' =
    assert (nf.facet_n1 <= nf.facet_n2);
    assert (nf'.facet_n1 <= nf'.facet_n2);
    if (nf.facet_n0 <> nf'.facet_n0 ||
          nf.facet_n1 <> nf'.facet_n1 ||
          nf.facet_n2 <> nf'.facet_n2) then
      false (* normalized m-value mismatch *)
    else
      let n0 = nf.facet_n0 in
      let n1 = nf.facet_n1 in
      let n2 = nf.facet_n2 in
      let n = n0 + n1 + n2 in
      let a_invariant = nf.facet_perm_sw_invariant in
      let b_invariant = nf'.facet_perm_sw_invariant in
      if NumTree.compare a_invariant b_invariant <> 0 then
        false (* permutation-switching invariant mismatch *)
      else
        let cuts_cnt = 1 lsl (n - 1) in
        let b_invariant = nf'.facet_perm_invariant in
        let rec iter1 cut =
          if cut = cuts_cnt then
            false (* by checking all switchings *)
          else begin
            let nf_sw = switch_normal_facet cut nf in
            if compare_facet_perm nf_sw nf' then
              true
            else
              iter1 (cut + 1)
          end
        in
        iter1 0

  let normalize_facet n0 n1 n2 ineq =
    let perm_sw_invariant = perm_invariant true n0 n1 n2 ineq in
    let perm_invariant = perm_invariant false n0 n1 n2 ineq in
    {
      facet_n0 = n0;
      facet_n1 = n1;
      facet_n2 = n2;
      facet_ineq = ineq;
      facet_perm_sw_invariant = perm_sw_invariant;
      facet_perm_invariant = perm_invariant;
    }

  type vertex =
      NoVertex
    | OriginalVertex of int
    | DetourVertex of int * int

  let trilift_ineq n0 n1 n2 ineq =
    let (internal_edges1, internal_edges2) =
      count_internal_edges n0 n1 n2 ineq in
    let m1 = n1 + internal_edges2 in
    let m2 = n2 + internal_edges1 in
    let v0 = if n0 = 1 then OriginalVertex 0 else NoVertex in
    let (ies1, ies2) = enumerate_internal_edges n0 n1 n2 ineq in
    let get_vertex = function
        IneqK1mm.X -> v0
      | IneqK1mm.A(i) ->
          if i < n1 then
            OriginalVertex (i + n0)
          else
            let (vi, vj) = ies2.(i - n1) in
            DetourVertex (vi, vj)
      | IneqK1mm.B(j) ->
          if j < n2 then
            OriginalVertex (j + n0 + n1)
          else
            let (vi, vj) = ies1.(j - n2) in
            DetourVertex (vi, vj)
    in
    let get_coeff vi vj =
      match (vi, vj) with
          (NoVertex, _) | (_, NoVertex) -> zero
        | (OriginalVertex vi, OriginalVertex vj) ->
            IneqKn.get_coeff ineq vi vj
        | (OriginalVertex v, DetourVertex (vi, vj))
        | (DetourVertex (vi, vj), OriginalVertex v) ->
            assert (vi < vj);
            if v = vi then
              IneqKn.get_coeff ineq vi vj
            else if v = vj then
              Number.abs (IneqKn.get_coeff ineq vi vj)
            else
              zero
        | (DetourVertex (_, _), DetourVertex (_, _)) -> zero
    in
    IneqK1mm.init m1 m2 (IneqKn.get_const_coeff ineq)
      (fun v w -> get_coeff (get_vertex v) (get_vertex w))

  let cut_to_cor_ineq ineq =
    let m1 = IneqK1mm.get_m1 ineq in
    let m2 = IneqK1mm.get_m2 ineq in
    let coeff_cor1 =
      Array.init m1 (fun i -> IneqK1mm.get_coeff ineq IneqK1mm.X (IneqK1mm.A(i)))
    in
    let coeff_cor2 =
      Array.init m2 (fun j -> IneqK1mm.get_coeff ineq IneqK1mm.X (IneqK1mm.B(j)))
    in
    let coeff_cor3 = Array.make (m1 * m2) zero in
    for i = 0 to m1 - 1 do
      for j = 0 to m2 - 1 do
        let coeff = IneqK1mm.get_coeff ineq (IneqK1mm.A(i)) (IneqK1mm.B(j)) in
        coeff_cor1.(i) <- Number.add coeff_cor1.(i) coeff;
        coeff_cor2.(j) <- Number.add coeff_cor2.(j) coeff;
        coeff_cor3.(i * m2 + j) <-
          Number.sub coeff_cor3.(i * m2 + j) (Number.mult two coeff)
      done
    done;
    for i = 0 to m1 - 1 do
      coeff_cor1.(i) <- Number.div coeff_cor1.(i) two
    done;
    for j = 0 to m2 - 1 do
      coeff_cor2.(j) <- Number.div coeff_cor2.(j) two
    done;
    for i = 0 to m1 * m2 - 1 do
      coeff_cor3.(i) <- Number.div coeff_cor3.(i) two
    done;
    (Number.div (IneqK1mm.get_const_coeff ineq) two,
     Array.concat [coeff_cor1; coeff_cor2; coeff_cor3])
end
