open Num
open Big_int
open Ratio
open Arith_status

let () = set_error_when_null_denominator false

let nan = num_of_ratio (create_ratio zero_big_int zero_big_int)
let zero = num_of_int 0
let one = num_of_int 1
let minus_one = num_of_int (-1)
