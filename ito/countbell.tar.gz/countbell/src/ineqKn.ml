(* $Id: ineqKn.ml 558 2004-12-21 05:23:16Z tsuyoshi $ *)

open Printf

module type NumberType = sig
  type t
  val of_int: int -> t
  val sign: t -> int
  val add: t -> t -> t
  val minus: t -> t
  val equal: t -> t -> bool
  val to_string: t -> string
end

module type S = sig
  type number
  type t
  val make: int -> t
  val copy: t -> t
  val get_n: t -> int
  val get_coeff: t -> int -> int -> number
  val set_coeff: t -> int -> int -> number -> unit
  val get_const_coeff: t -> number
  val set_const_coeff: t -> number -> unit
  val equal: t -> t -> bool
  val print: t -> unit
  val permute: int array -> t -> t
  val permute_equal: int array -> t -> t -> bool
  val minimize: t -> t
  val switch: int -> t -> t
end

module Make(Number: NumberType) = struct

  type number = Number.t

  let zero = Number.of_int 0

  type t = {
    n: int;
    a: number array;
  }

  let get_edge_idx n i j =
    assert (i >= 0 && i < n && j >= 0 && j < n && i != j);
    let (i, j) =
      if i < j then
        (i, j)
      else
        (j, i)
    in
    (n - 1 + n - i) * i / 2 + j - i

  let make n =
    {
      n = n;
      a = Array.make (n * (n - 1) / 2 + 1) zero;
    }

  let copy t =
    {
      n = t.n;
      a = Array.copy t.a;
    }

  let get_n t =
    t.n

  let get_coeff t i j =
    t.a.(get_edge_idx t.n i j)

  let set_coeff t i j coeff =
    t.a.(get_edge_idx t.n i j) <- coeff

  let get_const_coeff t =
    t.a.(0)

  let set_const_coeff t coeff =
    t.a.(0) <- coeff

  let equal t1 t2 =
    assert (t1.n = t2.n);
    let len = Array.length t1.a in
    let rec iter1 i =
      if i >= len then
        true
      else if not (Number.equal t1.a.(i) t2.a.(i)) then
        false
      else
        iter1 (i + 1)
    in
    iter1 0

  let print t =
    print_char ' ';
    Array.iter
      begin fun coeff ->
        printf " %s" (Number.to_string coeff)
      end
      t.a;
    print_newline ()

  let permute vs t =
    let n' = Array.length vs in
    let t' = make n' in
    set_const_coeff t' (get_const_coeff t);
    for i = 0 to n' - 2 do
      for j = i + 1 to n' - 1 do
        set_coeff t' i j (get_coeff t vs.(i) vs.(j))
      done
    done;
    t'

  let permute_equal vs t t' =
    assert (t.n = t'.n && Array.length vs = t.n);
    let n = t.n in
    try
      if not (Number.equal (get_const_coeff t) (get_const_coeff t')) then
        raise Exit;
      for i = 0 to n - 2 do
        for j = i + 1 to n - 1 do
          if not (Number.equal (get_coeff t vs.(i) vs.(j)) (get_coeff t' i j)) then
            raise Exit
        done
      done;
      true
    with Exit -> false

  let minimize t =
    let n = t.n in
    let vertex_used = Array.make n false in
    for i = 0 to n - 2 do
      for j = i + 1 to n - 1 do
        if Number.sign (get_coeff t i j) <> 0 then begin
          vertex_used.(i) <- true;
          vertex_used.(j) <- true
        end
      done
    done;
    let nmin = ref 0 in
    let vs = Array.make n 0 in
    for i = 0 to n - 1 do
      if vertex_used.(i) then begin
        vs.(!nmin) <- i;
        incr nmin
      end
    done;
    let nmin = !nmin in
    let vs = Array.sub vs 0 nmin in
    permute vs t

  let switch cut t =
    let n = t.n in
    let get_cut i j =
      ((cut lsr i) lxor (cut lsr j)) land 1
    in
    let t' = copy t in
    for i = 0 to n - 2 do
      for j = i + 1 to n - 1 do
        if get_cut i j = 1 then begin
          let edge_idx = get_edge_idx n i j in
          let c = t'.a.(edge_idx) in
          set_const_coeff t'
            (Number.add (get_const_coeff t') c);
          t'.a.(edge_idx) <- Number.minus c
        end
      done
    done;
    t'
end
