open Printf
open InitNum
open Util

module Number = struct
  open Num
  type t = num
  let of_int = num_of_int
  let sign = sign_num
  let compare = compare_num
  let add = add_num
  let sub = sub_num
  let mult = mult_num
  let div = div_num
  let minus = minus_num
  let equal = eq_num
  let abs = abs_num
  let to_string = string_of_num
end

module Int = struct
  type t = int
  let of_int a = a
  let sign a = if a > 0 then 1 else if a = 0 then 0 else -1
  let compare = compare
  let add = (+)
  let sub = (-)
  let mult = ( * )
  let div a b =
    assert (a mod b = 0);
    a / b
  let minus = (~-)
  let equal = (=)
  let abs = abs
  let to_string = string_of_int
end

let string_of_num = string_of_int
let minus_num = (~-)
let sign_num = Int.sign
let int_of_num a = a

module IneqKn = IneqKn.Make(Int)
module IneqK1mm = IneqK1mm.Make(Int)
module TriliftCompare = TriliftCompare.Make(Int)

open TriliftCompare

type print_option =
    Print_one
  | Print_root_switchings
  | Print_all_switchings
type print_cor_ineq_option =
    PrintCorIneq_no
  | PrintCorIneq_one_line
  | PrintCorIneq_two_dimensional

let print_src_ineq = false
let print_option = Print_one
let print_cut_ineq = true
let print_cor_ineq_option = PrintCorIneq_one_line

let parse_ineq n const_coeff lexbuf =
  let ineq = IneqKn.make n in
  IneqKn.set_const_coeff ineq const_coeff;
  for i = 0 to n - 2 do
    for j = i + 1 to n - 1 do
      match Lexer.num lexbuf with
          Lexer.NUM(num) ->
            IneqKn.set_coeff ineq i j num
        | _ -> failwith "parse_ineq: Illegal token"
    done
  done;
  if Lexer.num lexbuf <> Lexer.NEWLINE then
    failwith "parse_ineq: Illegal token; newline expected";
  ineq

let str_of_ineq n0 n1 n2 ineq =
  let n = IneqKn.get_n ineq in
  let rec iter1 vi vj =
    if vi >= n - 1 then
      []
    else if vj >= n then
      iter1 (vi + 1) (vi + 2)
    else
      IneqKn.get_coeff ineq vi vj :: iter1 vi (vj + 1)
  in
  String.concat " " (string_of_int n0 :: string_of_int n1 :: string_of_int n2 :: List.map string_of_int (iter1 0 1))

let generate_perms ineq =
  let n = IneqKn.get_n ineq in
  let vs = Array.make n (-1) in
  let sub1 perms v0 =
    let n0 =
      if v0 >= 0 then 1 else 0
    in
    let l = n - n0 in
    let group = Array.make l false in
    if v0 >= 0 then
      vs.(0) <- v0;
    let r_n1 = ref l in
    let r_n2 = ref 0 in
    let rec iter1 perms =
      let n1 = !r_n1 in
      let n2 = !r_n2 in
      let (swap_group, n1, n2) =
        if n1 < n2 then
          (false, n1, n2)
        else
          (true, n2, n1)
      in
      let j1 = ref n0 in
      let j2 = ref (n0 + n1) in
      Array.iteri
        begin fun j g ->
          let i =
            if v0 < 0 || j < v0 then
              j
            else
              j + 1
          in
          let g =
            if swap_group then
              not g
            else
              g
          in
          if g = false then begin
            vs.(!j1) <- i;
            incr j1
          end
          else begin
            vs.(!j2) <- i;
            incr j2
          end
        end
        group;
      let b = IneqKn.permute vs ineq in
      let str = str_of_ineq n0 n1 n2 b in
      let perms =
        ((n0, n1, n2, Array.copy vs), str) :: perms
      in
      let rec iter2 j =
        if j <= 0 then (* group.(0) is always false *)
          false
        else if group.(j) = false then begin
          group.(j) <- true;
          decr r_n1;
          incr r_n2;
          true
        end
        else begin
          group.(j) <- false;
          decr r_n2;
          incr r_n1;
          iter2 (j - 1)
        end
      in
      if iter2 (l - 1) then
        iter1 perms
      else
        perms
    in
    iter1 perms
  in
  let perms_n0_0 = sub1 [] (-1) in
  let perms_n0_0 =
    List.sort (fun (_, str) (_, str') -> compare str str') perms_n0_0
  in
  let perms_n0_0 =
    List.map fst (unique (fun (_, str) (_, str') -> str = str') perms_n0_0)
  in
  let perms_n0_1 = ref [] in
  for v0 = 0 to n - 1 do
    perms_n0_1 := sub1 !perms_n0_1 v0
  done;
  let perms_n0_1 = !perms_n0_1 in
  let perms_n0_1 =
    List.sort (fun (_, str) (_, str') -> compare str str') perms_n0_1
  in
  let perms_n0_1 =
    List.map fst (unique (fun (_, str) (_, str') -> str = str') perms_n0_1)
  in
  perms_n0_0 @ perms_n0_1

let trilift_and_print nf =
  let n0 = nf.facet_n0 in
  let n1 = nf.facet_n1 in
  let n2 = nf.facet_n2 in
  let ineq_lifted = trilift_ineq n0 n1 n2 nf.facet_ineq in
  let m1 = IneqK1mm.get_m1 ineq_lifted in
  let m2 = IneqK1mm.get_m2 ineq_lifted in
  let (n1, n2, m1, m2, ineq_lifted) =
    if m1 <= m2 then
      (n1, n2, m1, m2, ineq_lifted)
    else
      (n2, n1, m2, m1, IneqK1mm.exchange_partites ineq_lifted)
  in
  let (a0_cor, a_cor) = cut_to_cor_ineq ineq_lifted in
  if print_cut_ineq then begin
    printf "Cut %d %d | %d %d %d |" m1 m2 n0 n1 n2;
    let print_coeff v w =
      let coeff = IneqK1mm.get_coeff ineq_lifted v w in
      printf " %s" (string_of_int (-coeff))
    in
    for i = 0 to m1 - 1 do
      print_coeff IneqK1mm.X (IneqK1mm.A(i))
    done;
    for j = 0 to m2 - 1 do
      print_coeff IneqK1mm.X (IneqK1mm.B(j))
    done;
    for i = 0 to m1 - 1 do
      for j = 0 to m2 - 1 do
        print_coeff (IneqK1mm.A(i)) (IneqK1mm.B(j))
      done
    done;
    printf " <= %s\n" (string_of_int (IneqK1mm.get_const_coeff ineq_lifted))
  end;
  begin match print_cor_ineq_option with
      PrintCorIneq_no -> ()
    | PrintCorIneq_one_line ->
        printf "Cor %d %d | %d %d %d |" m1 m2 n0 n1 n2;
        Array.iter
          begin fun coeff ->
            printf " %s" (string_of_int (-coeff))
          end
          a_cor;
        printf " <= %s\n" (string_of_int a0_cor)
    | PrintCorIneq_two_dimensional ->
        printf "Cor %d %d, %d %d %d\n" m1 m2 n0 n1 n2;
        printf " %2s |" (string_of_int (-a0_cor));
        for i = 0 to m1 - 1 do
          printf " %2s" (string_of_num (minus_num a_cor.(i)))
        done;
        print_newline ();
        print_string " ---+";
        for i = 0 to m1 - 1 do
          print_string "---";
        done;
        print_newline ();
        for j = 0 to m2 - 1 do
          printf " %2s |" (string_of_num (minus_num a_cor.(m1 + j)));
          for i = 0 to m1 - 1 do
            printf " %2s" (string_of_num
                             (minus_num a_cor.(m1 + m2 + i * m2 + j)))
          done;
          print_newline ()
        done
  end;
  ()

let print_all_switchings only_root_switchings nf =
  let n = IneqKn.get_n nf.facet_ineq in
  let cuts_cnt = 1 lsl (n - 1) in
  let rec iter1 cut nfs =
    if cut = cuts_cnt then
      ()
    else begin
      let nf_sw = switch_normal_facet cut nf in
      if (only_root_switchings &&
            sign_num (IneqKn.get_const_coeff nf_sw.facet_ineq) <> 0) then
        iter1 (cut + 1) nfs
      else
        let same = List.exists (compare_facet_perm nf_sw) nfs in
        if same then
          iter1 (cut + 1) nfs
        else begin
          trilift_and_print nf_sw;
          iter1 (cut + 1) (nf_sw :: nfs)
        end
    end
  in
  iter1 0 [];
  ()

let report_ineq =
  match print_option with
      Print_one ->
        trilift_and_print
    | Print_root_switchings ->
        print_all_switchings true
    | Print_all_switchings ->
        print_all_switchings false

let bad_case n0 n1 n2 =
  assert (n1 <= n2);
  n1 = 0 && n0 + n2 = 3

let main () =
  let lexbuf = Lexing.from_channel stdin in
  let n =
    match Lexer.num lexbuf with
      Lexer.NUM(n) ->
        int_of_num n
    | _ ->
        failwith "main: Illegal token; integer expected"
  in
  let m1_limit =
    match Lexer.num lexbuf with
      Lexer.NUM(m1_limit) ->
        int_of_num m1_limit
    | _ ->
        failwith "main: Illegal token; integer expected"
  in
  let m2_limit =
    match Lexer.num lexbuf with
      Lexer.NUM(m2_limit) ->
        int_of_num m2_limit
    | _ ->
        failwith "main: Illegal token; integer expected"
  in

  let rec main_loop src_count output_count =
    match Lexer.num lexbuf with
      Lexer.EOF ->
        printf "Total %d\n" output_count;
        ()
    | Lexer.NEWLINE ->
        (* Ignore empty lines *)
        main_loop src_count output_count
    | Lexer.NUM(a0) ->
        (* printf "(%d)\n" (src_count + 1); *)
        let ineq_src = parse_ineq n a0 lexbuf in
        let ineq_src = IneqKn.minimize ineq_src in
        let n = IneqKn.get_n ineq_src in
        if print_src_ineq then
          IneqKn.print ineq_src;
        let edge_cnt = ref 0 in
        for i = 0 to n - 2 do
          for j = i + 1 to n - 1 do
            if sign_num (IneqKn.get_coeff ineq_src i j) <> 0 then
              incr edge_cnt
          done
        done;
        let edge_cnt = !edge_cnt in
        let output_count =
          if edge_cnt > (n - 1) * (n - 1) / 4 + m1_limit + m2_limit then
            output_count
          else begin
            let perms = generate_perms ineq_src in
            let rec iter3 output_count ineqs = function
                [] -> output_count
              | (n0, n1, n2, vs) :: perms_tl ->
                  if bad_case n0 n1 n2 then
                    iter3 output_count ineqs perms_tl
                  else begin
                    let ineq_a = IneqKn.permute vs ineq_src in
                    let (internal_edges1, internal_edges2) =
                      count_internal_edges n0 n1 n2 ineq_a
                    in
                    let m1 = n1 + internal_edges2 in
                    let m2 = n2 + internal_edges1 in
                    if m1 > m1_limit || m2 > m2_limit then
                      iter3 output_count ineqs perms_tl
                    else
                      let nf = normalize_facet n0 n1 n2 ineq_a in
                      let same =
                        List.exists
                          (fun nf' -> compare_facet_perm_sw nf nf')
                          ineqs
                      in
                      if same then begin
                        iter3 output_count ineqs perms_tl
                      end
                      else begin
                        printf "* (%d) <- input %d\n"
                          (output_count + 1) (src_count + 1);
                        report_ineq nf;
                        flush stdout;
                        iter3 (output_count + 1) (nf :: ineqs) perms_tl
                      end
                  end
            in
            iter3 output_count [] perms
          end
        in
        (* flush stdout; *)
        main_loop (src_count + 1) output_count
    | _ ->
        failwith "main_loop: Illegal token"
  in
  main_loop 0 0

let () = main ()
